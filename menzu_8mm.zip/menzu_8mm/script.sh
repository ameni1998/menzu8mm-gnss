    mkdir /sys/class/gpio/gpio87/ 0777
    mkdir /sys/class/gpio/gpio87/value 0777
    mkdir /sys/class/gpio/gpio87/direction 0777

    write /sys/class/gpio/export 87
    write /sys/class/gpio/gpio87/direction out
    write /sys/class/gpio/gpio87/value 1

    mkdir /sys/class/gpio/gpio85/ 0777
    mkdir /sys/class/gpio/gpio85/value 0777
    mkdir /sys/class/gpio/gpio85/direction 0777
    
    write /sys/class/gpio/export 85
    write /sys/class/gpio/gpio85/direction out
    write /sys/class/gpio/gpio85/value 1

    mkdir /sys/class/gpio/gpio86/ 0777
    mkdir /sys/class/gpio/gpio86/value 0777
    mkdir /sys/class/gpio/gpio86/direction 0777

    write /sys/class/gpio/export 86
    write /sys/class/gpio/gpio86/direction out
    write /sys/class/gpio/gpio86/value 1
